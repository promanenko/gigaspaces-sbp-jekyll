﻿using System;
using System.IO;
using GigaSpaces.Core;
using GigaSpaces.Examples.Datagrid.Commons.Entities;
using GigaSpaces.XAP.ProcessingUnit.Containers;

namespace GigaSpaces.Examples.Datagrid.Client
{
    internal class Program
    {
        public static string RemoteUrl = "jini://*/*/datagrid?groups=myGroup";
        private const int NumberOfIterations = 10;

        private static void Main(string[] args)
        {
            var options = new Options();
            if (CommandLine.Parser.Default.ParseArgumentsStrict(args, options,
                () => Console.WriteLine("Parsing arguments failed")))
            {
                try
                {
                    Console.WriteLine("Preforming: {0}", options.Action);
                    switch (options.Action)
                    {
                        case Actions.debug:
                            ForDebugging();
                            break;
                        case Actions.write:
                            DemoWrite();
                            break;
                        case Actions.writeMultiple:
                            DemoWriteMultiple();
                            break;
                        case Actions.readbyid:
                            DemoReadById();
                            break;
                        case Actions.readMultiple:
                            DemoReadMultiple();
                            break;
                    }

                    Console.WriteLine("Performed: {0}", options.Action);

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }

        //---------------------------------------------------------------------------------------------------

        private static void DemoReadMultiple()
        {
            var spaceProxy = GigaSpacesFactory.FindSpace(RemoteUrl);

            for (int i = 0; i < NumberOfIterations; i++)
            {
                String query = "Age > " + (i * 10);

                var persons = spaceProxy.ReadMultiple<Person>(new SqlQuery<Person>(query));

                Console.WriteLine("ReadMultiple been called - Query:" + query + " Found " + persons.Length + " matching Persons");

                foreach (var p in persons)
                {
                    if (p != null)
                    {
                        PrintPerson(p);
                    }
                }
            }
        }

        //---------------------------------------------------------------------------------------------------

        private static void PrintPerson(Person p)
        {
            Console.WriteLine("Person ID = {0}, firstName = {1}, lastName = {2}, Age = {3} ",
                p.Id, p.FirstName, p.LastName, p.Age);
        }

        //---------------------------------------------------------------------------------------------------
        
        private static void DemoReadById()
        {
            var spaceProxy = GigaSpacesFactory.FindSpace(RemoteUrl);

            SqlQuery<Person> query = new SqlQuery<Person>("Age > " + (10));
            query.Projections = new[] { "Id" };

            // Using Projections  - getting only IDs
            var persons = spaceProxy.ReadMultiple<Person>(
                query, 10);

            foreach (var p in persons)
            {
                var person = spaceProxy.ReadById<Person>(p.Id);

                if (p != null)
                {
                    PrintPerson(p);
                }
            }
        }

        //---------------------------------------------------------------------------------------------------
        
        private static void DemoWriteMultiple()
        {
            var spaceProxy = GigaSpacesFactory.FindSpace(RemoteUrl);
            var counter = 1;

            while (counter < NumberOfIterations)
            {
                var personarray = new Person[NumberOfIterations];
                for (int i = 0; i < NumberOfIterations; i++)
                {
                    personarray[i] = new Person
                    {
                        Age = (counter * NumberOfIterations + i) % 120, 
                        FirstName = "Name" + counter, 
                        LastName = "lastname" + counter, 
                        Id = Math.Abs((Guid.NewGuid().GetHashCode())) };
                }
                counter++;
                spaceProxy.WriteMultiple(personarray);
            }

        }

        //---------------------------------------------------------------------------------------------------
        
        private static void DemoWrite()
        {
            var spaceProxy = GigaSpacesFactory.FindSpace(RemoteUrl);

            var counter = 101;
            for (int i = 0; i < NumberOfIterations; i++)
            {
                var person = new Person { Age = counter % 120, 
                    FirstName = "Name" + counter, 
                    LastName = "lastname" + counter, 
                    Id = Math.Abs((Guid.NewGuid().GetHashCode())) };
                counter++;
                spaceProxy.Write(person);
            }
        }


        /// <summary>
        /// Run ProcessingUnitContainers to execute full PU lifecycle locally, for debug purposes.
        /// </summary>
        private static void ForDebugging()
        {

            Console.WriteLine("Press enter to start the processing units and press enter again to stop the processing units");
            Console.ReadLine();

            var primaryClusterInfo = new ClusterInfo("partitioned-sync2backup", 1, null, 1, 1);
            var backupClusterInfo = new ClusterInfo("partitioned-sync2backup", 1, 1, 1, 1);

            String deployPath = Path.GetFullPath(@"..\..\..\Deploy");
            var primaryProcessorContainerHost = new ProcessingUnitContainerHost(Path.Combine(deployPath, "datagrid"), primaryClusterInfo, null);
            var backupProcessorContainerHost = new ProcessingUnitContainerHost(Path.Combine(deployPath, "datagrid"), backupClusterInfo, null);
            var mirrorContainerHost = new ProcessingUnitContainerHost(Path.Combine(deployPath, "mirror"), null, null);

            Console.ReadLine();
            backupProcessorContainerHost.Dispose();
            primaryProcessorContainerHost.Dispose();
            mirrorContainerHost.Dispose();
        }
    }
}