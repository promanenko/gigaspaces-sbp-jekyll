﻿using System;

using CommandLine;

namespace GigaSpaces.Examples.Datagrid.Client
{
    public enum Actions
    {
        none,
        debug,
        write,
        writeMultiple,
        readbyid,
        readMultiple
    }
    [Serializable]
    public class Options
    {
        [Option(HelpText = "The action to perform: readbyid,readMultiple,write,writeMultiple", Required = true)]
        public Actions Action { get; set; }
    }
}
