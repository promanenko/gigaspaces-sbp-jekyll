﻿using System;
using System.Collections.Generic;
using GigaSpaces.Examples.Datagrid.Commons;

namespace GigaSpaces.Examples.Datagrid
{
    
    /// <summary>
    /// Processor config
    /// </summary>
    public class ProcessorConfig
    {
        #region Defaults
        private const string EnableMirrorDefault = "true";
        private const bool UseTxDefault = false;
        #endregion

        #region Fields

        /// <summary>
        /// Initialization url to the space.
        /// </summary>
        private readonly string _spaceUrl;
        /// <summary>
        /// Url to find the mirror service
        /// </summary>
        private readonly string _mirrorUrl;
        /// <summary>
        /// Enable Mirror
        /// </summary>
        private readonly string _enableMirror;
        /// <summary>
        /// Use transactions for the processing logic
        /// </summary>
        private readonly bool _useTx;

        #endregion
 
        #region Costructor

        public ProcessorConfig(IDictionary<string, string> properties)
        {
            _enableMirror = EnableMirrorDefault;
            _useTx = UseTxDefault;

            properties.TryGetValue("SpaceUrl", out _spaceUrl);
            if (string.IsNullOrEmpty(_spaceUrl))
                throw new ArgumentException("Space URL must be defined.");

            properties.TryGetValue("MirrorUrl", out _mirrorUrl);
            if (string.IsNullOrEmpty(_mirrorUrl))
                throw new ArgumentException("Mirror URL must be defined.");

            try
            {
                string tempVal;

                properties.TryGetValue("EnableMirror", out tempVal);
                if (!string.IsNullOrEmpty(tempVal))
                    _enableMirror = tempVal;

                properties.TryGetValue("UseTx", out tempVal);
                if (!string.IsNullOrEmpty(tempVal))
                    _useTx = bool.Parse(tempVal);

            }
            catch (Exception ee)
            {
                Reporter.Report("Error parsing configuration - Using defaults");
                Reporter.Report(ee.Message);
                Reporter.Report(ee.StackTrace);
            }

            Reporter.Report("Configuration loaded:");
            Reporter.Report(this);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Initialization url to the space.
        /// </summary>
        public string SpaceUrl
        {
            get { return _spaceUrl; }
        }

        /// <summary>
        /// Url to find the mirror service
        /// </summary>
        public string MirrorUrl
        {
            get { return _mirrorUrl; }
        }

        /// <summary>
        /// Enable Mirror
        /// </summary>
        public string EnableMirror
        {
            get { return _enableMirror; }
        }

        /// <summary>
        /// Use transactions for the processing logic
        /// </summary>
        public bool UseTx
        {
            get { return _useTx; }
        }

 
    	#endregion

        public override string ToString()
        {
            return "Processor PU Config:" + Environment.NewLine +
                   "* SpaceUrl = " + SpaceUrl + Environment.NewLine +
                   "* Enable Mirror = " + EnableMirror + Environment.NewLine +
                   "* MirrorUrl = " + MirrorUrl + Environment.NewLine +
                   "* UseTx = " + UseTx + Environment.NewLine +
                   "End of ProcessorPuConfig." + Environment.NewLine;
        }

    }
}