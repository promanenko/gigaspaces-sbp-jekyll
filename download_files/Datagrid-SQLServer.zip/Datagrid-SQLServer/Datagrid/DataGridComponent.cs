using System;
using System.Collections.Generic;
using System.Xml.Linq;
using GigaSpaces.Core;
using GigaSpaces.Core.Persistency;
using GigaSpaces.Examples.Datagrid.Commons;
using GigaSpaces.XAP.ProcessingUnit.Containers.BasicContainer;

namespace GigaSpaces.Examples.Datagrid
{
	/// <summary>
	/// This component is responsible for starting up the colocated space it will process the
	/// data from with an external data source.
	/// </summary>
	[BasicProcessingUnitComponent]
	public class DataGridComponent : IDisposable
	{
		[ContainerInitializing]
		public void Initialize(BasicProcessingUnitContainer container)
		{
			Reporter.Report("Starting Processor");

			//Create config for the processor
			ProcessorConfig processorConfig = new ProcessorConfig(container.Properties);

			//Create a new space configuration object that is used to start a space
			SpaceConfig spaceConfig = new SpaceConfig();

			//Set a new ExternalDataSource config object
			spaceConfig.ExternalDataSourceConfig = EdsUtils.BuildNHibernateExternalDataSource();

			//Our cluster member should only use the external data source in read only mode since the
			//mirror persist the data to the data base (Async persistency)
			spaceConfig.ExternalDataSourceConfig.Usage = Usage.ReadOnly;

			//Add custom properties
			
            spaceConfig.CustomProperties = new Dictionary<string, string>
            {
                {"space-config.engine.cache_policy", "1"},
                {"cluster-config.cache-loader.external-data-source", "true"},
                {"cluster-config.cache-loader.central-data-source", "true"},
                {"cluster-config.mirror-service.enabled",processorConfig.EnableMirror},
                {"cluster-config.mirror-service.url", processorConfig.MirrorUrl}
            };

			// create cluster member space:
			ISpaceProxy spaceProxy = container.CreateSpaceProxy("datagrid", processorConfig.SpaceUrl, spaceConfig);
			Reporter.Report(" Datagrid: Space proxy created: " + processorConfig.SpaceUrl);
		}

		public void Dispose()
		{
			Reporter.Report("Processor shutdown");
		}
	}
}
