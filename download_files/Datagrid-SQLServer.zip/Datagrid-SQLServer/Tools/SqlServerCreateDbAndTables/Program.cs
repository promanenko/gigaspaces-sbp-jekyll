using System;
using GigaSpaces.Practices.ExternalDataSource.NHibernate;
using NHibernate;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace Tools.SqlServerDb
{
    class Program
    {
        private const string nhibernateCreateTablesConfigFilePath = "../config/nHibernate/CreateTablesNHibernate.cfg.xml";
        private const string nhibernateHmbFilePath = "../config/nHibernate/";

        static void Main(string[] args)
        {
            Console.WriteLine();
            Console.WriteLine("-------------------------------------");
            Console.WriteLine("  SqlServer Create Tables Started    ");
            Console.WriteLine("-------------------------------------");
            Console.WriteLine();
            {
                try
                {
                    Console.WriteLine("* Creating tables");
                    NHibernate.Cfg.Configuration factoryConfig = new NHibernate.Cfg.Configuration();
                    factoryConfig.Configure(nhibernateCreateTablesConfigFilePath);
                    string hbmDir = Path.GetFullPath(nhibernateHmbFilePath);
                    factoryConfig.AddDirectory(new DirectoryInfo(hbmDir));
                    factoryConfig.BuildSessionFactory();
                    Console.WriteLine("* Tables created");
                }
                catch(Exception ex)
                {
                    Console.WriteLine();
                    Console.WriteLine("** Exception: " + ex.Message);
                    Console.WriteLine(ex.StackTrace);
                }
            }
            Console.WriteLine();
            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();
        }
    }
}
