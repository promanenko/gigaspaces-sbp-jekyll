using System;
using System.Collections.Generic;
using GigaSpaces.Core;
using GigaSpaces.Examples.Datagrid.Commons;
using GigaSpaces.XAP.ProcessingUnit.Containers.BasicContainer;

namespace GigaSpaces.Examples.Datagrid.Mirror
{
	[BasicProcessingUnitComponent(Name = "Mirror")]
	public class MirrorComponent : IDisposable
	{

		[ContainerInitializing]
		public void Initialize(BasicProcessingUnitContainer container)
		{
			Reporter.Report("Starting Mirror");

		    string partitions;
		    string backupPerPartition;

		    ConfigHelper.GetPartitionsFromSla(out partitions, out backupPerPartition);

		    //Create a new space configuration object that is used to start a space
			var spaceConfig = new SpaceConfig
			{
			    ExternalDataSourceConfig = EdsUtils.BuildNHibernateExternalDataSource()
			};

			//Set a new ExternalDataSource config object

		    //The usage in mirror is ignored.
            spaceConfig.ExternalDataSourceConfig.Usage = null;

			//Configure mirror source cluster properties
		    spaceConfig.CustomProperties = new Dictionary<String, String>
		    {
		        {"space-config.mirror-service.cluster.name", "datagrid"},
		        {"space-config.mirror-service.cluster.partitions", partitions},
		        {"space-config.mirror-service.cluster.backups-per-partition", backupPerPartition}
		    };

		    //Init the mirror space using the container
            MirrorConfig mirrorConfig = new MirrorConfig(container.Properties);
            container.CreateSpaceProxy("mirror_datagrid", mirrorConfig.SpaceUrl, 
                spaceConfig);
            Reporter.Report("Mirror started");
		}



	    public void Dispose()
		{
			Reporter.Report("Mirror shutdown");
		}

	}
}
