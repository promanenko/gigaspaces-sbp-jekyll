﻿using System;
using System.Collections.Generic;
using GigaSpaces.Examples.Datagrid.Commons;

namespace GigaSpaces.Examples.Datagrid.Mirror
{
    /// <summary>
    /// Mirror config
    /// </summary>
    internal class MirrorConfig
    {
        /// <summary>
        /// The url to initialize the mirror
        /// </summary>
        private readonly string _spaceUrl;

        public MirrorConfig(IDictionary<string, string> properties)
        {
            properties.TryGetValue("SpaceUrl", out _spaceUrl);
            if (string.IsNullOrEmpty(_spaceUrl))
                throw new ArgumentException("Space URL must be defined.");

            Reporter.Report("Configuration loaded:");
            Reporter.Report(this);
        }

        /// <summary>
        /// The url to initialize the mirror
        /// </summary>
        public string SpaceUrl
        {
            get
            {
                 return _spaceUrl;
            }
        }

        public override string ToString()
        {
            return "Mirror Config:" + Environment.NewLine +
                   "* SpaceUrl = " + SpaceUrl + Environment.NewLine +
                   "End of Mirror Config." + Environment.NewLine + Environment.NewLine;
        }
    }
}