﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using GigaSpaces.Core.Persistency;
using GigaSpaces.Core;
using GigaSpaces.Practices.ExternalDataSource.NHibernate;

namespace GigaSpaces.Examples.Datagrid.Commons
{
    public class EdsUtils
    {
        /// <summary>
        /// Build NHibernate External Data Source
        /// </summary>
        /// <returns>The prepared ExternalDataSourceConfig</returns>
        public static ExternalDataSourceConfig BuildNHibernateExternalDataSource()
        {
            ExternalDataSourceConfig externalDataSourceConfig = new ExternalDataSourceConfig();

            //Start a new instance of NHibernateExternalDataSource.
            NHibernateExternalDataSource hibernateExternalDataSource = new NHibernateExternalDataSource();

            //Since the demo should run on a single machine as well, decrease the number of initial load threads to 3, because it might overwhelm the database with too many concurrent sessions.
            hibernateExternalDataSource.InitialLoadThreadPoolSize = 3;

            //Attach the NHibernateExternalDataSource to the config
            externalDataSourceConfig.Instance = hibernateExternalDataSource;


            //Create custom properties that are required to build NHibernate session factory
            externalDataSourceConfig.CustomProperties = new Dictionary<string, string>
            {
            //Point to NHibernate session factory config file
                {
                    NHibernateExternalDataSource.NHibernateConfigProperty,
                    AppDomain.CurrentDomain.BaseDirectory + @"\NHibernateCfg\nHibernate.cfg.xml"
                },
            //Optional - points to a directory that contains the NHibernate mapping files (hbm)
                {
                    NHibernateExternalDataSource.NHibernateHbmDirectory,
                    AppDomain.CurrentDomain.BaseDirectory + @"\NHibernateCfg\"
                }
            };
            return externalDataSourceConfig;
        }
    }
}
