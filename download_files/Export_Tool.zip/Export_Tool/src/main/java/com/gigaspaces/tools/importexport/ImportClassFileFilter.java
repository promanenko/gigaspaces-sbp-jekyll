package com.gigaspaces.tools.importexport;

import java.io.File;
import java.io.FilenameFilter;

public class ImportClassFileFilter implements FilenameFilter {
	private static String SUFFIX = ".ser.gz";
	private Integer partitionId;
	
	public ImportClassFileFilter(Integer partitionId) { 
		
		this.partitionId = partitionId;
	}
	
	@Override
	public boolean accept(File dir, String name) {

		// currently there are no checks for directory - it should be automatic
		if (name.endsWith(partitionId + SUFFIX)) return true;
		return false;
	}
}
