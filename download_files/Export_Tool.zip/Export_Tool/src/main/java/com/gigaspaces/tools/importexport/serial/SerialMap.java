package com.gigaspaces.tools.importexport.serial;

import java.io.Serializable;
import java.util.HashMap;


public class SerialMap extends HashMap<String, Serializable> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5613280612377927961L;
	
	

}
