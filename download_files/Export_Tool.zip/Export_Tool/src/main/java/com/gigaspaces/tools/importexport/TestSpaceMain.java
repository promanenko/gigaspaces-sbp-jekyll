package com.gigaspaces.tools.importexport;

import org.openspaces.core.GigaSpace;
import org.openspaces.core.GigaSpaceConfigurer;
import org.openspaces.core.cluster.ClusterInfo;
import org.openspaces.core.space.UrlSpaceConfigurer;

public class TestSpaceMain {

	public static void main(String[] args) {

		ClusterInfo cf = new ClusterInfo();
		cf.setName("space");
		cf.setSchema("partitioned");
		cf.setNumberOfInstances(2);
		cf.setInstanceId(1);
		GigaSpace space1 = new GigaSpaceConfigurer(new UrlSpaceConfigurer("/./space").clusterInfo(cf)).gigaSpace();
		cf.setInstanceId(2);

		GigaSpace space2 = new GigaSpaceConfigurer(new UrlSpaceConfigurer("/./space").clusterInfo(cf)).gigaSpace();

		System.out.println("space started");
	}

}
